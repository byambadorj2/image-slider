//
//  SliderCell.swift
//  Image-slider
//
//  Created by World Plus on 5/28/21.
//  Copyright © 2021 World Plus. All rights reserved.
//

import UIKit

class SliderCell: UICollectionViewCell {
   
    @IBOutlet weak var imageView: UIImageView!
    
    var image: UIImage! {
        didSet {
            imageView.image = image
        }
    }
    
}
