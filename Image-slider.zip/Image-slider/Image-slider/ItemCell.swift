//
//  ItemCell.swift
//  Image-slider
//
//  Created by World Plus on 5/31/21.
//  Copyright © 2021 World Plus. All rights reserved.
//

import UIKit

class ItemCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var productNameLabel: UILabel!
    @IBOutlet weak var detailLabel: UILabel!
    
   
}
