//
//  ViewController.swift
//  Image-slider
//
//  Created by World Plus on 5/28/21.
//  Copyright © 2021 World Plus. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var ListCollectionView: UICollectionView!
    
//    let images = [
//        UIImage(named: "tree1"),
//        UIImage(named: "tree2"),
//        UIImage(named: "tree3"),
//        UIImage(named: "tree4"),
//    ]
    let detail = ["Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book."]
    
    let magazines = ["Weekly","Sed","Forbes","Soronz","Forbes","Soronz","Weekly","Sed","Forbes","Soronz","Forbes","Soronz"]
    let magazineImages: [UIImage] = [
          UIImage(named: "1")!,
          UIImage(named: "2")!,
          UIImage(named: "3")!,
          UIImage(named: "4")!,
          UIImage(named: "5")!,
          UIImage(named: "6")!,
          UIImage(named: "1")!,
          UIImage(named: "2")!,
          UIImage(named: "3")!,
          UIImage(named: "4")!,
          UIImage(named: "5")!,
          UIImage(named: "6")!,
    ]
    
    var currentIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ListCollectionView.dataSource = self
        ListCollectionView.delegate = self

        pageControl.numberOfPages = magazineImages.count
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        return images.count
        return magazineImages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = ListCollectionView.dequeueReusableCell(withReuseIdentifier: "ItemCell", for: indexPath) as! ItemCell
        cell.imageView.image = magazineImages[indexPath.row]
        cell.productNameLabel.text = magazines[indexPath.row]
        
        return cell

        
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let _: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard?.instantiateViewController(withIdentifier: "DetailVC") as! DetailVC
        vc.image = magazineImages[indexPath.row]
        vc.name = magazines[indexPath.row]
//        vc.det = detail[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
    }

    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: collectionView.frame.width, height: collectionView.frame.height)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        currentIndex = Int(scrollView.contentOffset.x / ListCollectionView.frame.size.width)
        
        pageControl.currentPage = currentIndex
    }
}

